"""Virtual ultrasonic sensors for Project Luna Argus.

Local use:  python simulator.py
Hosted use: python simulator.py --url https://YOUR-SERVICE.onrender.com
You can also set LUNA_ARGUS_URL instead of passing --url.
"""
import argparse
import json
import os
import random
import time
import urllib.request
from datetime import datetime

import config

DEFAULT_URL = "http://127.0.0.1:5000"
BAYS = [f"{z}{n}" for z in config.ZONES for n in range(1, config.BAYS_PER_ZONE + 1)]


def arrival_bias(hour):
    """Probability that a toggle is an arrival (vs. a departure)."""
    return 0.75 if 12 <= hour < 15 else 0.5 if 9 <= hour < 18 else 0.3


def read_distance(occupied):
    """Simulated HC-SR04 reading in cm."""
    return round(random.uniform(5, 25) if occupied else random.uniform(80, 200), 1)


def send(bay, distance, url):
    payload = json.dumps({
        "bay_id": bay, "distance_cm": distance, "source": "sensor"
    }).encode()
    req = urllib.request.Request(
        url.rstrip("/") + "/api/telemetry",
        payload,
        {"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        response.read()


def main():
    parser = argparse.ArgumentParser(description="Luna Argus virtual sensors")
    parser.add_argument("--speed", type=float, default=1.0, help="2.0 = twice as fast")
    parser.add_argument("--seed", type=int, help="random seed for repeatable demos")
    parser.add_argument(
        "--url",
        default=os.environ.get("LUNA_ARGUS_URL", DEFAULT_URL),
        help="base URL of the Flask app (local or deployed Render URL)",
    )
    args = parser.parse_args()
    if args.speed <= 0:
        parser.error("--speed must be greater than zero")
    if args.seed is not None:
        random.seed(args.seed)

    state = {b: random.random() < 0.3 for b in BAYS}
    print(f"Luna Argus simulator: {len(BAYS)} virtual sensors -> {args.url}")
    print("Press Ctrl+C to stop.")
    try:
        for bay in BAYS:
            send(bay, read_distance(state[bay]), args.url)
        while True:
            bay = random.choice(BAYS)
            if random.random() < 0.5:
                arrive = random.random() < arrival_bias(datetime.now().hour)
                state[bay] = arrive
            send(bay, read_distance(state[bay]), args.url)
            print(f"{datetime.now():%H:%M:%S}  {bay:<3} "
                  f"{'OCCUPIED' if state[bay] else 'FREE'}")
            time.sleep(random.uniform(0.8, 2.5) / args.speed)
    except KeyboardInterrupt:
        print("\nSimulator stopped.")
    except OSError as exc:
        print("Backend unreachable. Check the URL and make sure the web app is running:", exc)


if __name__ == "__main__":
    main()
