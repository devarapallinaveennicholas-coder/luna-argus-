"""Central settings for Project Luna Argus."""
import os

# On Render, set DB_PATH=/var/data/parking.db only if you attach a disk
# mounted at /var/data. Without a disk, the database is temporary.
DB_PATH = os.environ.get("DB_PATH", "parking.db")
ZONES = "ABC"            # Zone letters -> A1..A8, B1..B8, C1..C8 (24 bays)
BAYS_PER_ZONE = 8
OCCUPIED_BELOW_CM = 30   # Ultrasonic reading below this distance = vehicle present
STALE_AFTER_SECONDS = 15 # Warn if no sensor has reported for this long
EVENT_LOG_LIMIT = 30
